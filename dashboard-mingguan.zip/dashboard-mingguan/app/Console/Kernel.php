protected $commands = [
    \App\Console\Commands\InstallApp::class,
];
